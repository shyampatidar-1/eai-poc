export const secretCodeAES = "0cdc66ca70a13aaec7959d52bfb7b502d9e55ac12a7b2446f61e52c44fee0040";
export const SITE_NAME = "Doctor & Patient App";
export const API_RESPONSE = { MESSAGE_503: "Please try again later, something went wrong!", };
export const DEFAULT_PAGE_LENGTH = 5;