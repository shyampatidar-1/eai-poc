import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { EYE_CLOSE, EYE_OPEN } from "../../utils/aap-image-constant";
import BreadCrum from "../../components/comman/breadcrum";
import Input from "../../components/comman/input";
import Button from "../../components/comman/button";
import { ROUTES } from "../../hooks/routes/routes-constant";
import { handleFormInput, handleFormNumericInput } from "../../utils/form-utils";
import DropDown from "../../components/comman/dropdown";
import INPUTFIELD from "../../components/comman/input";
import { addStaff, getAllRole, getPasswordPolicy, getStaffById, staffList, updateStaff } from "../../hooks/services/api-services";
import { API_RESPONSE } from "../../utils/app-constants";
import { decryptAEStoJSON, toastEmitter } from "../../utils/utilities";
import { useSelector } from "react-redux";
import { Spinner } from "react-bootstrap";

const AddStaff = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isPwdVisible, setIsPwdVisible] = useState("password");
  const { value } = useSelector((state) => state?.loggedUser);
  const userData = decryptAEStoJSON(value);
  const [payload, setPayload] = useState({
    adminId: 0,
    userName: "",
    password: "",
    roleId: 0,
    policyId: 0
  });

  const location = useLocation();
  const navigate = useNavigate();
  const checkFormType = location?.state?.formType || "add";
  const staffId = location?.state?.staffId;
  console.log("staffId>>>", staffId);

  const pageAction =
    checkFormType === "add"
      ? "Add"
      : checkFormType === "edit"
        ? "Edit"
        : "View";

  const handleDataBack = () => {
    setPayload({
      adminId: 0,
      userName: "",
      password: "",
      roleId: 0,
      policyId: 0
    });
    navigate(ROUTES.STAFF);
  };
  const roleliste = [
    { label: "Admin", value: 1 },
    { label: "Receptionist", value: 2 },
    { label: "Therapist", value: 3 },
  ];



  // get staff bu id
  const fetchStaffById = async (staffId) => {
    try {
      const response = await getStaffById(staffId);
      if (response.status !== 200) {
        toastEmitter("error", response?.data?.message);
      } else {
        let rowData = response?.data?.data;
        setPayload({
          adminId: rowData?.adminId,
          userName: rowData?.userName,
          roleId: rowData?.roleId,
          policyId: rowData?.policyId
        });
      }
    } catch (err) {
      toastEmitter("error", API_RESPONSE?.MESSAGE_503);
    }
  };
  useEffect(() => {
    if (staffId) {
      fetchStaffById(staffId);
    }
  }, [staffId]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (payload.userName.trim() === "") {
      return toastEmitter("error", "Username is mandatory!");
    }
    if (checkFormType === "add") {
      if (payload.password.trim() === "") {
        return toastEmitter("error", "Password is mandatory!");
      }
    }
    setIsLoading(true);
    try {
      const response = await (checkFormType === "add" ? addStaff(payload) : updateStaff(payload));
      console.log("RESPONSE ->", response);
      if (response.data?.status !== 200) {
        toastEmitter("error", response?.data?.message);
      }
      if (response.data?.status === 200) {
        toastEmitter("success", response?.data?.message);
        navigate(ROUTES.STAFF);
      }
    } catch (error) {
      toastEmitter("error", API_RESPONSE?.MESSAGE_503);
    } finally {
      setIsLoading(false);
    }
  };

  // role list

  // role list fetch
  const [rolelist, setRoleList] = useState([]);
  const fetchRoleData = async () => {
    const rolePayload = {
      pageIndex: 0,
      pageSize: 0,
      searchBy: "",
      sortingOrder: "desc",
      sortBy: "",
      status: 0,
      parentRoleId: 0,
    }
    try {
      const response = await getAllRole(rolePayload);
      if (response?.data?.status !== 200) {
        toastEmitter("error", response?.data?.message);
        setRoleList([]);
      } else {
        setRoleList(response?.data?.data);
      }
    } catch (err) {
      // if (isFirstRender.current) {
      toastEmitter("error", API_RESPONSE?.MESSAGE_503);
      // }
    } finally {

      // isFirstRender.current = false; // Toast ek baar dikhane ke baad disable kar diya
    }
  };


  // passwod policy list
  const [policies, setPolicies] = useState([]);
  const passwordPolicyList = async () => {
    // setIsLoading(true);
    const tablePayload = {
      pageIndex: 0,
      pageSize: 0,
      sortBy: "",
      searchBy: "",
      sortingOrder: "",
    };
    try {
      const response = await getPasswordPolicy(tablePayload)
      if (response.data?.status !== 200) {
        // toastEmitter("error", response?.data?.message);
        setPolicies([])
      }
      if (response.data?.status === 200) {
        setPolicies(response?.data?.data)
      }
    } catch (error) {
      toastEmitter("error", API_RESPONSE?.MESSAGE_503);
    }
    finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchRoleData();
    passwordPolicyList()
  }, []);
  return (
    <div className="main_datatable my-lg-3 mt-1">
      <BreadCrum
        firstData="Staff"
        iconshow1={true}
        secondData={`${pageAction} Staff`}
        onFirstDataClick={handleDataBack}
      />
      <form onSubmit={handleSubmit}>
        <div className="add_doctor card p-3 border border-radius_input mb-3">


          <div className="row">
            <div className="col-md-6 mb-2">
              <INPUTFIELD
                className="border-radius_input"
                type="text"
                value={payload.userName}
                disabled={checkFormType === "view"}
                name="userName"
                placeHolder="Enter user name"
                handleChange={(e) => setPayload(handleFormInput(e, payload))}
                labelName="Staff Name"
              />
            </div>

            {/* <div className="col-md-6 mb-2">
              <INPUTFIELD
                className="border-radius_input"
                type="email"
                value={payload.email}
                disabled={checkFormType === "view"}
                name="email"
                placeHolder="Enter email"
                handleChange={(e) => setPayload(handleFormInput(e, payload))}
                labelName="Staff Email"
              />
            </div> */}
            <div className="col-md-6 mb-2">

              <label htmlFor="">
                Role Name <span className="text-danger">*</span>
              </label>
              <select
                class="form-select"
                disabled={checkFormType === "view"}
                name="roleId"
                value={payload.roleId || ""}
                onChange={(e) =>
                  setPayload(
                    handleFormNumericInput(e, payload)
                  )
                }
              >
                <option value="0" className="font-primary">
                  Select Role
                </option>
                {rolelist !== undefined &&
                  rolelist &&
                  rolelist
                    ?.sort((a, b) =>
                      a?.roleName?.localeCompare(b?.roleName)
                    )
                    ?.map((item) => (
                      <option key={item?.roleId} value={item?.roleId}>
                        {item?.roleName}
                      </option>
                    ))}
              </select>


            </div>
            <div className="col-md-6 mb-2">

              <label htmlFor="">
                Password Policy <span className="text-danger">*</span>
              </label>
              <select
                class="form-select"
                disabled={checkFormType === "view"}
                name="policyId"
                value={payload.policyId || ""}
                onChange={(e) =>
                  setPayload(
                    handleFormNumericInput(e, payload)
                  )
                }
              >
                <option value="0" className="font-primary">
                  Select Password Policy
                </option>
                {policies !== undefined &&
                  policies &&
                  policies
                    ?.sort((a, b) =>
                      a?.passwordPolicyName?.localeCompare(b?.passwordPolicyName)
                    )
                    ?.map((item) => (
                      <option key={item?.policyId} value={item?.policyId}>
                        {item?.passwordPolicyName}
                      </option>
                    ))}
              </select>


            </div>

            {checkFormType === "add" && (
              <div className="col-md-6 mb-2">
                <INPUTFIELD
                  className="border-radius_input"
                  type={isPwdVisible}
                  value={payload.password}
                  name="password"
                  placeHolder="Enter your password"
                  handleChange={(e) => setPayload(handleFormInput(e, payload))}
                  labelName="Password"
                  showRightIcon={true}
                  disabled={checkFormType === "view"}
                  rightIconSrc={
                    isPwdVisible === "password" ? EYE_CLOSE : EYE_OPEN
                  }
                  onRightIconClick={() =>
                    setIsPwdVisible(
                      isPwdVisible === "password" ? "text" : "password"
                    )
                  }
                />
              </div>
            )}
          </div>
        </div>

        <div className="d-flex flex-wrap justify-content-center">
          <Button
            type="button"
            className="px-4 py-2 rounded border-0 cancelbtn mb-2 me-3"
            label="Cancel"
            onClick={handleDataBack}
          />

          {checkFormType !== "view" && (
            <button
              type="submit"
              className="px-4 py-2 rounded border-0 text-white btn-primary mb-2"
              disabled={isLoading}
            >
              {isLoading && <Spinner animation="border" size="sm" className='me-2' />}
              {pageAction} Staff
            </button>
          )}
        </div>
      </form >
    </div >
  );
};

export default AddStaff;
